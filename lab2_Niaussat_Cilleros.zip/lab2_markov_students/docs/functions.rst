functions module
================

.. automodule:: functions
   :members:
   :undoc-members:
   :show-inheritance:
