lab2_markov_students
====================

.. toctree::
   :maxdepth: 4

   functions
